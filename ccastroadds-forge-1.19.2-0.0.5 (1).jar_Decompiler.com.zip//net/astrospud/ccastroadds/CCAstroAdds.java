package net.astrospud.ccastroadds;

import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.astrospud.ccastroadds.config.CCAAConfig;
import net.astrospud.ccastroadds.registration.CCAADispenserBehaviors;
import net.astrospud.ccastroadds.registration.CCAAItems;
import net.astrospud.ccastroadds.registration.CCAAStatusEffects;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.config.CCConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod("ccastroadds")
public class CCAstroAdds {
   public static CCAAConfig config;
   public static final String MOD_ID = "ccastroadds";
   public static final Logger LOGGER = LoggerFactory.getLogger("ccastroadds");
   public static final CreativeModeTab ORGAN_ITEM_GROUP = new CreativeModeTab("ccastroadds.organs") {
      public ItemStack m_6976_() {
         return new ItemStack((ItemLike)CCAAItems.STEEL_DISTRIBUTOR.get());
      }
   };

   public CCAstroAdds() {
      AutoConfig.register(CCAAConfig.class, GsonConfigSerializer::new);
      config = (CCAAConfig)AutoConfig.getConfigHolder(CCAAConfig.class).getConfig();
      ChestCavity.config = ChestCavity.config == null ? new CCConfig() : ChestCavity.config;
      CCAAItems.registerModItems();
      KeyBindings.register();
      IEventBus eventBus = FMLJavaModLoadingContext.get().getModEventBus();
      eventBus.addListener(this::common);
      CCAAItems.ITEMS.register(eventBus);
      CCAAStatusEffects.MOB_EFFECTS.register(eventBus);
   }

   public void common(FMLCommonSetupEvent event) {
      event.enqueueWork(CCAADispenserBehaviors::register);
   }
}
