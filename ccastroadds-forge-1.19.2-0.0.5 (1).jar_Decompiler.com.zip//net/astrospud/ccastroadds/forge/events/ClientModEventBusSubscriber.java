package net.astrospud.ccastroadds.forge.events;

import net.astrospud.ccastroadds.KeyBindings;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(
   modid = "ccastroadds",
   value = {Dist.CLIENT},
   bus = Bus.MOD
)
public class ClientModEventBusSubscriber {
   @SubscribeEvent
   public static void registerKeys(RegisterKeyMappingsEvent event) {
      event.register(KeyBindings.FLIGHT);
   }
}
