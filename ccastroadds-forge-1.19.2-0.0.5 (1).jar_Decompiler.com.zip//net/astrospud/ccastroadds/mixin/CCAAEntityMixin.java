package net.astrospud.ccastroadds.mixin;

import net.minecraft.world.entity.Entity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({Entity.class})
public abstract class CCAAEntityMixin {
   private ChestCavityInstance chestCavityInstance;

   protected CCAAEntityMixin() {
   }
}
