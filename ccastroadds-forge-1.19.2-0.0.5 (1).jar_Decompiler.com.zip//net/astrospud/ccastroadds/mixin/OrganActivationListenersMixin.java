package net.astrospud.ccastroadds.mixin;

import net.astrospud.ccastroadds.registration.CCAAOrganScores;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.listeners.OrganActivationListeners;
import net.tigereye.chestcavity.registration.CCStatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({OrganActivationListeners.class})
public abstract class OrganActivationListenersMixin {
   @Inject(
      at = {@At("HEAD")},
      method = {"ActivateGrazing"},
      remap = false
   )
   private static void ccaaActivateGrazingMixin(LivingEntity entity, ChestCavityInstance cc, CallbackInfo info) {
      float grazing = cc.getOrganScore(CCAAOrganScores.EAT_THE_RICH);
      if (!(grazing <= 0.0F)) {
         BlockPos blockPos = entity.m_20183_().m_7495_();
         boolean ateGrass = false;
         if (entity.f_19853_.m_8055_(blockPos).m_60734_().m_7325_() <= 6.0F && !entity.f_19853_.m_8055_(blockPos).m_155947_() && !entity.f_19853_.m_8055_(blockPos).m_60734_().m_5568_() && !(entity.f_19853_.m_8055_(blockPos).m_60734_() instanceof LiquidBlock)) {
            entity.f_19853_.m_46597_(blockPos, Blocks.f_50016_.m_49966_());
            ateGrass = true;
         }

         if (ateGrass) {
            int duration;
            if (entity.m_21023_((MobEffect)CCStatusEffects.RUMINATING.get())) {
               MobEffectInstance ruminating = entity.m_21124_((MobEffect)CCStatusEffects.RUMINATING.get());
               duration = (int)Math.min((float)(ChestCavity.config.RUMINATION_TIME * ChestCavity.config.RUMINATION_GRASS_PER_SQUARE * ChestCavity.config.RUMINATION_SQUARES_PER_STOMACH) * grazing, (float)(ruminating.m_19557_() + ChestCavity.config.RUMINATION_TIME * ChestCavity.config.RUMINATION_GRASS_PER_SQUARE));
            } else {
               duration = ChestCavity.config.RUMINATION_TIME * ChestCavity.config.RUMINATION_GRASS_PER_SQUARE;
            }

            duration = (int)((float)duration + 20.0F * entity.f_19853_.m_8055_(blockPos).m_60734_().m_7325_());
            entity.m_7292_(new MobEffectInstance((MobEffect)CCStatusEffects.RUMINATING.get(), duration, 0, false, false, true));
         }
      }

   }
}
