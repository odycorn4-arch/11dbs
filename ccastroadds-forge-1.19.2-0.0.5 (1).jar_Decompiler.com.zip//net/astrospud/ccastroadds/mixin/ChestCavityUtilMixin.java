package net.astrospud.ccastroadds.mixin;

import net.tigereye.chestcavity.util.ChestCavityUtil;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ChestCavityUtil.class})
public abstract class ChestCavityUtilMixin {
}
