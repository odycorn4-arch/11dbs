package net.astrospud.ccastroadds.mixin.forge;

import net.astrospud.ccastroadds.listeners.CCAAOrganOnHitListeners;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.listeners.OrganOnHitListeners;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({OrganOnHitListeners.class})
public class OrganOnHitMixin {
   @Inject(
      at = {@At("RETURN")},
      method = {"call"},
      remap = false
   )
   private static void addCall(LivingEntity attacker, LivingEntity target, ChestCavityInstance cc, CallbackInfo ci) {
      CCAAOrganOnHitListeners.call(attacker, target, cc);
   }
}
