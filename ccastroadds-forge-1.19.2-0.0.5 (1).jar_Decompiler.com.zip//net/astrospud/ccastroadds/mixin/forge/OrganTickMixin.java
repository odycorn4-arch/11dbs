package net.astrospud.ccastroadds.mixin.forge;

import net.astrospud.ccastroadds.listeners.CCAAOrganTickListeners;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.listeners.OrganTickListeners;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({OrganTickListeners.class})
public class OrganTickMixin {
   @Inject(
      at = {@At("RETURN")},
      method = {"call"},
      remap = false
   )
   private static void addCall(LivingEntity entity, ChestCavityInstance cc, CallbackInfo ci) {
      CCAAOrganTickListeners.call(entity, cc);
   }
}
