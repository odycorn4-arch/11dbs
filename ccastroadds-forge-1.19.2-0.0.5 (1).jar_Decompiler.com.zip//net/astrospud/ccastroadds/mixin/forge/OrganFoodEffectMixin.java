package net.astrospud.ccastroadds.mixin.forge;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import net.astrospud.ccastroadds.listeners.CCAAOrganFoodEffectListeners;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.listeners.OrganFoodEffectListeners;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({OrganFoodEffectListeners.class})
public class OrganFoodEffectMixin {
   @Inject(
      at = {@At("RETURN")},
      method = {"call"},
      cancellable = true,
      remap = false
   )
   private static void addCall(List<Pair<MobEffectInstance, Float>> list, ItemStack itemStack, Level world, LivingEntity entity, ChestCavityInstance cc, CallbackInfoReturnable<List<Pair<MobEffectInstance, Float>>> cir) {
      cir.setReturnValue(CCAAOrganFoodEffectListeners.call((List)cir.getReturnValue(), itemStack, world, entity, cc));
   }
}
