package net.astrospud.ccastroadds.mixin;

import net.astrospud.ccastroadds.listeners.CCAAOrganOnDamageListeners;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class CCAALivingEntityMixin extends Entity implements ChestCavityEntity {
   private ChestCavityInstance chestCavityInstance;

   protected CCAALivingEntityMixin(EntityType<? extends LivingEntity> entityType, Level world) {
      super(entityType, world);
   }

   @Inject(
      at = {@At("RETURN")},
      method = {"hurt"}
   )
   private void ccaaDamageMixin(DamageSource source, float amount, CallbackInfoReturnable<Boolean> info) {
      if ((Boolean)info.getReturnValue()) {
         CCAAOrganOnDamageListeners.call((LivingEntity)this, source, amount);
      }

   }
}
