package net.astrospud.ccastroadds.mixin;

import net.astrospud.ccastroadds.registration.CCAAOrganScores;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.listeners.OrganTickListeners;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({OrganTickListeners.class})
public abstract class OrganTickListenersMixin {
   @Inject(
      at = {@At("HEAD")},
      method = {"TickBuoyant"},
      cancellable = true,
      remap = false
   )
   private static void CCAATickBuoyantMixin(LivingEntity entity, ChestCavityInstance chestCavity, CallbackInfo cir) {
      float buoyancy = chestCavity.getOrganScore(CCAAOrganScores.NEUTRAL_WATER_BUOYANT) - chestCavity.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.NEUTRAL_WATER_BUOYANT);
      if (buoyancy > 0.0F && (entity.m_20069_() || entity.m_20077_())) {
         cir.cancel();
      }

   }
}
