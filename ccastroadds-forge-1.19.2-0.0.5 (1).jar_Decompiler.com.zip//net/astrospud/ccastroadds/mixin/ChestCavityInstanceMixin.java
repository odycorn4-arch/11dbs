package net.astrospud.ccastroadds.mixin;

import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ChestCavityInstance.class})
public abstract class ChestCavityInstanceMixin {
}
