package net.astrospud.ccastroadds.util;

import java.util.Iterator;
import java.util.List;
import net.astrospud.ccastroadds.registration.CCAAItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.chestcavities.ChestCavityInventory;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;

public class AstralCavityUtil {
   static Item[] growable_tumors;
   static List<Item> infectable_tumors;
   static List<Item> harmful_tumors;

   public static void growBackOrgans(LivingEntity entity, ChestCavityInstance cc, float count) {
      count = (float)Mth.m_14167_(count);
      ChestCavityInventory def = cc.getChestCavityType().getDefaultChestCavity();

      for(int i = 0; i < def.m_6643_() && count > 0.0F; ++i) {
         ItemStack organHas = cc.inventory.m_8020_(i);
         ItemStack organDefault = def.m_8020_(i);
         organDefault.m_41764_(organDefault.m_41741_());
         if (organHas.m_41619_()) {
            if (organDefault.m_41619_() || (double)entity.m_217043_().m_188501_() <= 0.25D || organDefault.m_41720_() == Items.f_42329_) {
               organDefault = getTumor(entity);
               organDefault.m_41764_(organDefault.m_41741_());
            }

            if (!organDefault.m_41619_() && !(entity instanceof Player)) {
               CompoundTag tag = new CompoundTag();
               tag.m_128362_("owner", cc.compatibility_id);
               tag.m_128359_("name", cc.owner.m_5446_().getString());
               organDefault.m_41700_(ChestCavity.COMPATIBILITY_TAG.toString(), tag);
               organDefault.m_41764_(organDefault.m_41741_());
            }

            organDefault.m_41764_(organDefault.m_41741_());
            cc.inventory.m_6836_(i, organDefault);
            if (entity instanceof Player) {
               Player player = (Player)entity;
               if (organDefault.m_41614_() && organDefault.m_41720_().m_41473_() != null) {
                  player.m_36399_(0.25F * (float)organDefault.m_41613_() * ((float)organDefault.m_41720_().m_41473_().m_38744_() + organDefault.m_41720_().m_41473_().m_38745_()));
               } else {
                  player.m_36399_(0.25F);
               }
            }

            --count;
         }
      }

   }

   public static void eatOrgans(LivingEntity entity, ChestCavityInstance cc, float count, boolean tumorous) {
      count = (float)Mth.m_14167_(count);
      ChestCavityInventory def = cc.getChestCavityType().getDefaultChestCavity();

      for(int i = 0; i < def.m_6643_() && count > 0.0F; ++i) {
         ItemStack organHas = cc.inventory.m_8020_(i);
         if (organHas.m_41614_()) {
            for(int g = 0; g < organHas.m_41613_() && count > 0.0F; ++g) {
               if (entity instanceof Player) {
                  Player player = (Player)entity;
                  if (player.m_36324_().m_38721_()) {
                     player.m_5584_(player.m_9236_(), organHas);
                     if (tumorous && organHas.m_41613_() <= 0 || organHas.m_41619_() && (double)entity.m_217043_().m_188501_() <= 0.5D) {
                        organHas = getTumor(entity);
                     }

                     cc.inventory.m_6836_(i, organHas);
                     --count;
                     continue;
                  }
               }

               if (entity.m_21223_() < entity.m_21233_()) {
                  entity.m_5634_(1.0F);
                  organHas.m_41774_(1);
                  if (tumorous && organHas.m_41613_() <= 0 || organHas.m_41619_() && (double)entity.m_217043_().m_188501_() <= 0.5D) {
                     organHas = getTumor(entity);
                  }

                  cc.inventory.m_6836_(i, organHas);
                  --count;
               }
            }
         }
      }

   }

   public static void huntTumors(LivingEntity entity, ChestCavityInstance cc, float count) {
      count = (float)Mth.m_14167_(count);
      ChestCavityInventory def = cc.getChestCavityType().getDefaultChestCavity();

      for(int i = 0; i < def.m_6643_() && count > 0.0F; ++i) {
         ItemStack organHas = cc.inventory.m_8020_(i);
         if (harmful_tumors.contains(organHas.m_41720_())) {
            organHas = ItemStack.f_41583_;
            cc.inventory.m_6836_(i, organHas);
            --count;
         }
      }

   }

   public static void infectOrgans(LivingEntity entity, ChestCavityInstance cc, float count) {
      count = (float)Mth.m_14167_(count);
      ChestCavityInventory def = cc.getChestCavityType().getDefaultChestCavity();

      for(int i = 0; i < def.m_6643_() && count > 0.0F; ++i) {
         ItemStack organHas = cc.inventory.m_8020_(i);
         if (organHas.m_41614_() || infectable_tumors.contains(organHas.m_41720_())) {
            for(int g = 0; g < organHas.m_41613_() && count > 0.0F; ++g) {
               organHas = ((Item)CCAAItems.SCULK_TUMOR.get()).m_7968_();
               cc.inventory.m_6836_(i, organHas);
               --count;
            }
         }
      }

   }

   public static void drinkMilk(LivingEntity entity, ChestCavityInstance cc) {
      ChestCavityInventory def = cc.getChestCavityType().getDefaultChestCavity();

      for(int i = 0; i < def.m_6643_(); ++i) {
         ItemStack organHas = cc.inventory.m_8020_(i);
         List<MobEffect> effects = entity.m_21221_().keySet().stream().toList();
         boolean drink = false;
         Iterator var7 = effects.iterator();

         MobEffect e;
         while(var7.hasNext()) {
            e = (MobEffect)var7.next();
            if (e.m_19483_() == MobEffectCategory.HARMFUL) {
               drink = true;
               break;
            }
         }

         if (organHas.m_41720_() == Items.f_42455_ && drink) {
            organHas = Items.f_42446_.m_7968_();
            organHas.m_41764_(1);
            entity.m_5496_(SoundEvents.f_11911_, 1.0F, 1.0F);
            cc.inventory.m_6836_(i, organHas);
            var7 = effects.iterator();

            while(var7.hasNext()) {
               e = (MobEffect)var7.next();
               if (e.m_19483_() == MobEffectCategory.HARMFUL) {
                  entity.m_21195_(e);
               }
            }

            return;
         }
      }

   }

   public static void dropOrgans(LivingEntity entity, ChestCavityInstance cc, float count) {
      count = (float)Mth.m_14167_(count);
      ChestCavityInventory def = cc.getChestCavityType().getDefaultChestCavity();

      for(int i = 0; i < def.m_6643_() && count > 0.0F; ++i) {
         ItemStack organHas = cc.inventory.m_8020_(i);
         if (!organHas.m_41619_()) {
            cc.inventory.m_6836_(i, ItemStack.f_41583_);
            ItemEntity e = new ItemEntity(entity.f_19853_, entity.m_20185_(), entity.m_20186_(), entity.m_20189_(), organHas);
            entity.f_19853_.m_7967_(e);
            --count;
         }
      }

   }

   public static ItemStack getTumor(LivingEntity entity) {
      return growable_tumors[entity.m_217043_().m_188503_(growable_tumors.length)].m_7968_();
   }

   static {
      growable_tumors = new Item[]{(Item)CCAAItems.BENIGN_TUMOR.get(), (Item)CCAAItems.AUTOPHAGY_TUMOR.get()};
      infectable_tumors = List.of((Item)CCAAItems.BENIGN_TUMOR.get(), (Item)CCAAItems.AUTOPHAGY_TUMOR.get());
      harmful_tumors = List.of((Item)CCAAItems.AUTOPHAGY_TUMOR.get(), (Item)CCAAItems.SCULK_TUMOR.get());
   }
}
