package net.astrospud.ccastroadds.util;

import net.astrospud.ccastroadds.KeyBindings;
import net.tigereye.chestcavity.registration.CCKeybindings;

public class KeyBindingToggleUtil {
   private static boolean flightButton = false;
   public static boolean isFlying = false;

   public static void tick() {
      if ((KeyBindings.FLIGHT.m_90857_() || CCKeybindings.UTILITY_ABILITIES.m_90857_()) && !flightButton) {
         flightButton = true;
         isFlying = !isFlying;
      }

      if (!KeyBindings.FLIGHT.m_90857_() && !CCKeybindings.UTILITY_ABILITIES.m_90857_()) {
         flightButton = false;
      }

   }
}
