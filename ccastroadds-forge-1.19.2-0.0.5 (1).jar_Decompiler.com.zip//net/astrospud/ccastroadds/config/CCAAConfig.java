package net.astrospud.ccastroadds.config;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry.Category;

@Config(
   name = "ccastroadds"
)
public class CCAAConfig implements ConfigData {
   @Category("cooldown")
   public int REGROWTH_COOLDOWN = 400;
   @Category("cooldown")
   public int AUTOPHAGY_COOLDOWN = 450;
   @Category("cooldown")
   public int SCULK_INFECTION_COOLDOWN = 500;
   @Category("cooldown")
   public int TUMOR_HUNTING_COOLDOWN = 250;
}
