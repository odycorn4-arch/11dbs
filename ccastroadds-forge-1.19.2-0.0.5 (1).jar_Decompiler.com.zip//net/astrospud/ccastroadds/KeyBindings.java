package net.astrospud.ccastroadds;

import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.ResourceLocation;

public class KeyBindings {
   public static KeyMapping FLIGHT;

   public static void register() {
      FLIGHT = register(new ResourceLocation("ccastroadds", "flight"), "util", 46);
   }

   public static KeyMapping register(ResourceLocation id, String category, int defaultKey) {
      String var10000 = id.m_135827_();
      String var10002 = "key." + var10000 + "." + id.m_135815_();
      Type var10003 = Type.KEYSYM;
      String var10005 = id.m_135827_();
      return new KeyMapping(var10002, var10003, defaultKey, "category." + var10005 + "." + category);
   }
}
