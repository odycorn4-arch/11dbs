package net.astrospud.ccastroadds.specials;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class GlintItem extends Item {
   public GlintItem(Properties settings) {
      super(settings);
   }

   public void m_7373_(ItemStack stack, @Nullable Level world, List<Component> tooltip, TooltipFlag context) {
      super.m_7373_(stack, world, tooltip, context);
   }

   public boolean m_5812_(ItemStack stack) {
      return true;
   }
}
