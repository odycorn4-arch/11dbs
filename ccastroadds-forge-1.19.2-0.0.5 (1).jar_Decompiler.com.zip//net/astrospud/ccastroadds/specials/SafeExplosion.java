package net.astrospud.ccastroadds.specials;

import java.util.List;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.ProtectionEnchantment;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class SafeExplosion extends Explosion {
   private double x;
   private double y;
   private double z;
   private Entity pentity;
   private float power;
   private Level privateWorld = null;

   public SafeExplosion(Level world, @Nullable Entity entity, double px, double py, double pz, float ppower) {
      super(world, entity, px, py, pz, ppower);
      this.privateWorld = world;
      this.x = px;
      this.y = py;
      this.z = pz;
      this.power = ppower;
      this.pentity = entity;
   }

   public void m_46061_() {
      float q = Math.abs(this.power * 3.0F);
      int k = Mth.m_14107_(this.x - (double)q - 1.0D);
      int l = Mth.m_14107_(this.x + (double)q + 1.0D);
      int r = Mth.m_14107_(this.y - (double)q - 1.0D);
      int s = Mth.m_14107_(this.y + (double)q + 1.0D);
      int t = Mth.m_14107_(this.z - (double)q - 1.0D);
      int u = Mth.m_14107_(this.z + (double)q + 1.0D);
      List<Entity> list = this.privateWorld.m_45933_(this.pentity, new AABB((double)k, (double)r, (double)t, (double)l, (double)s, (double)u));
      Vec3 vec3d = new Vec3(this.x, this.y, this.z);

      for(int v = 0; v < list.size(); ++v) {
         Entity entity = (Entity)list.get(v);
         if (!(entity instanceof ItemEntity) && entity != this.pentity && !(entity instanceof ExperienceOrb)) {
            double w = Math.sqrt(entity.m_20238_(vec3d)) / (double)q;
            if (w <= 1.0D) {
               double x = entity.m_20185_() - this.x;
               double y = (entity instanceof PrimedTnt ? entity.m_20186_() : entity.m_20188_()) - this.y;
               double z = entity.m_20189_() - this.z;
               double aa = Math.sqrt(x * x + y * y + z * z);
               if (aa != 0.0D) {
                  x /= aa;
                  y /= aa;
                  z /= aa;
                  double ab = (double)m_46064_(vec3d, entity);
                  double ac = (1.0D - w) * ab;
                  double ad = ac;
                  if (entity instanceof LivingEntity) {
                     ad = ProtectionEnchantment.m_45135_((LivingEntity)entity, ac);
                  }

                  entity.m_20256_(entity.m_20184_().m_82520_(x * ad * 2.0D, y * ad / 3.0D + 0.2D, z * ad * 2.0D));
                  if (entity instanceof Player) {
                     Player playerEntity = (Player)entity;
                     if (!playerEntity.m_5833_() && (!playerEntity.m_7500_() || !playerEntity.m_150110_().f_35935_)) {
                        this.m_46078_().put(playerEntity, new Vec3(x * ac * 2.0D, y * ac / 3.0D + 0.2D, z * ac * 2.0D));
                     }
                  }
               }
            }
         }
      }

   }
}
