package net.astrospud.ccastroadds.specials;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.astrospud.ccastroadds.util.AstralCavityUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockSource;
import net.minecraft.core.Direction;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.phys.AABB;
import net.tigereye.chestcavity.chestcavities.ChestCavityInventory;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.items.ChestOpener;
import net.tigereye.chestcavity.registration.CCOrganScores;
import net.tigereye.chestcavity.util.ChestCavityUtil;

public class ChestOpenerDispenserBehavior extends DefaultDispenseItemBehavior {
   protected ItemStack m_7498_(BlockSource pointer, ItemStack stack) {
      ServerLevel world = pointer.m_7727_();
      if (!world.m_5776_()) {
         BlockPos blockPos = pointer.m_7961_().m_121945_((Direction)pointer.m_6414_().m_61143_(DispenserBlock.f_52659_));
         tryMutilateEntity(world, blockPos, (ChestOpener)stack.m_41720_());
      }

      return stack;
   }

   private static void tryMutilateEntity(ServerLevel world, BlockPos pos, ChestOpener stack) {
      List<LivingEntity> list = world.m_6443_(LivingEntity.class, new AABB(pos), EntitySelector.f_20408_);
      Iterator var4 = list.iterator();

      while(var4.hasNext()) {
         LivingEntity livingEntity = (LivingEntity)var4.next();
         if (openChestCavity(livingEntity)) {
            ChestCavityEntity ccE = (ChestCavityEntity)livingEntity;
            AstralCavityUtil.dropOrgans(livingEntity, ccE.getChestCavityInstance(), 1.0F);
         }
      }

   }

   public static boolean openChestCavity(LivingEntity target) {
      Optional<ChestCavityEntity> optional = ChestCavityEntity.of(target);
      if (optional.isPresent()) {
         ChestCavityEntity chestCavityEntity = (ChestCavityEntity)optional.get();
         ChestCavityInstance cc = chestCavityEntity.getChestCavityInstance();
         if (!cc.getChestCavityType().isOpenable(cc)) {
            if (target.f_19853_.f_46443_) {
               if (!target.m_6844_(EquipmentSlot.CHEST).m_41619_()) {
                  target.m_5496_(SoundEvents.f_11744_, 1.0F, 0.75F);
               } else {
                  target.m_5496_(SoundEvents.f_11680_, 1.0F, 0.75F);
               }
            }

            return false;
         } else {
            if (cc.getOrganScore(CCOrganScores.EASE_OF_ACCESS) > 0.0F) {
               if (target.f_19853_.f_46443_) {
                  target.m_5496_(SoundEvents.f_11749_, 1.0F, 0.75F);
               }
            } else {
               target.m_6469_(DamageSource.f_19318_, 4.0F);
            }

            if (target.m_6084_()) {
               String name;
               try {
                  name = target.m_5446_().getString();
                  name = name.concat("'s ");
               } catch (Exception var6) {
                  name = "";
               }

               ChestCavityInventory var5 = ChestCavityUtil.openChestCavity(cc);
            }

            return true;
         }
      } else {
         return false;
      }
   }
}
