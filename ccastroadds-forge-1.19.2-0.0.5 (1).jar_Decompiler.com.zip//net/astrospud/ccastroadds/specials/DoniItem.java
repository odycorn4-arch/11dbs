package net.astrospud.ccastroadds.specials;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.ClickEvent.Action;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class DoniItem extends Item {
   public DoniItem(Properties settings) {
      super(settings);
   }

   public void m_7373_(ItemStack stack, @Nullable Level world, List<Component> tooltip, TooltipFlag context) {
      tooltip.add(Component.m_237115_("tooltip.ccastroadds.doniitem").m_130940_(ChatFormatting.GOLD));
      tooltip.add(Component.m_237115_("tooltip.ccastroadds.right").m_130940_(ChatFormatting.GRAY));
      super.m_7373_(stack, world, tooltip, context);
   }

   public InteractionResultHolder<ItemStack> m_7203_(Level world, Player user, InteractionHand hand) {
      if (!world.f_46443_) {
         user.m_213846_(Component.m_237115_("msg.ccastroadds.click").m_6270_(Style.f_131099_.m_131162_(true).m_131157_(ChatFormatting.GOLD).m_131142_(new ClickEvent(Action.OPEN_URL, "https://www.youtube.com/c/DoniBobesMC"))));
      }

      return super.m_7203_(world, user, hand);
   }
}
