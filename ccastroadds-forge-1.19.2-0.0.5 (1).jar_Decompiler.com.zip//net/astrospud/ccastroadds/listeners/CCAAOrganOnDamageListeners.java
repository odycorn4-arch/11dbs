package net.astrospud.ccastroadds.listeners;

import net.astrospud.ccastroadds.registration.CCAAOrganScores;
import net.astrospud.ccastroadds.registration.CCAAStatusEffects;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;

public class CCAAOrganOnDamageListeners {
   public static void call(LivingEntity entity, DamageSource source, float amount) {
      TickPanic(entity, source, amount);
   }

   public static void TickPanic(LivingEntity entity, DamageSource source, float amount) {
      if (entity instanceof ChestCavityEntity) {
         ChestCavityInstance cc = ((ChestCavityEntity)entity).getChestCavityInstance();
         float panic = cc.getOrganScore(CCAAOrganScores.PANIC) - cc.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.PANIC);
         if (!(panic <= 0.0F) && !entity.m_21023_((MobEffect)CCAAStatusEffects.PANIC.get())) {
            int power = (int)Math.floor(2.0D * Math.log10((double)(panic + 1.0F)));
            int duration = (int)(100.0D * Math.log10((double)(2.0F * panic - 1.0F))) + 100;
            entity.m_7292_(new MobEffectInstance((MobEffect)CCAAStatusEffects.PANIC.get(), duration, power, false, true, true));
         }
      }

   }
}
