package net.astrospud.ccastroadds.listeners;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import net.astrospud.ccastroadds.registration.CCAAOrganScores;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;

public class CCAAOrganFoodEffectListeners {
   public static List<Pair<MobEffectInstance, Float>> call(List<Pair<MobEffectInstance, Float>> list, ItemStack itemStack, Level world, LivingEntity entity, ChestCavityInstance cc) {
      return applyIrongut(list, itemStack, world, entity, cc);
   }

   private static List<Pair<MobEffectInstance, Float>> applyIrongut(List<Pair<MobEffectInstance, Float>> list, ItemStack itemStack, Level world, LivingEntity entity, ChestCavityInstance cc) {
      float rotten = cc.getOrganScore(CCAAOrganScores.IRON_GUT);
      if (rotten > 0.0F) {
         list.removeIf((pair) -> {
            return ((MobEffectInstance)pair.getFirst()).m_19544_().m_19483_() == MobEffectCategory.HARMFUL;
         });
      }

      return list;
   }
}
