package net.astrospud.ccastroadds.listeners;

import net.astrospud.ccastroadds.CCAstroAdds;
import net.astrospud.ccastroadds.registration.CCAAOrganScores;
import net.astrospud.ccastroadds.util.AstralCavityUtil;
import net.astrospud.ccastroadds.util.KeyBindingToggleUtil;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec2;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;

public class CCAAOrganTickListeners {
   public static void call(LivingEntity entity, ChestCavityInstance chestCavity) {
      TickNeutralWaterBuoyant(entity, chestCavity);
      TickFlight(entity, chestCavity);
      TickRegrowth(entity, chestCavity);
      TickTumorAutophagy(entity, chestCavity);
      TickTumorHunt(entity, chestCavity);
      TickSculkInfection(entity, chestCavity);
      TickAutophagy(entity, chestCavity);
   }

   public static void TickNeutralWaterBuoyant(LivingEntity entity, ChestCavityInstance chestCavity) {
      float buoyancy = chestCavity.getOrganScore(CCAAOrganScores.NEUTRAL_WATER_BUOYANT) - chestCavity.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.NEUTRAL_WATER_BUOYANT);
      if (entity instanceof Player) {
         Player ent = (Player)entity;
         if (ent.m_7500_() && ent.m_150110_().f_35935_) {
            return;
         }
      }

      if (!entity.m_20096_() && !entity.m_20068_() && !(buoyancy <= 0.0F)) {
         if (entity.m_20077_()) {
            entity.m_5997_(0.0D, 0.02D, 0.0D);
         } else if (entity.m_20069_()) {
            entity.m_5997_(0.0D, 0.005D, 0.0D);
         }
      }

   }

   public static void TickFlight(LivingEntity entity, ChestCavityInstance chestCavity) {
      if (entity instanceof Player) {
         Player player = (Player)entity;
         if (player instanceof ChestCavityEntity) {
            ChestCavityEntity e = (ChestCavityEntity)player;
            if (e.getChestCavityInstance().getOrganScore(CCAAOrganScores.FLIGHT) > 0.0F) {
               KeyBindingToggleUtil.tick();
               if (player.m_150110_().f_35935_) {
                  KeyBindingToggleUtil.isFlying = false;
               }

               Input input = new Input();
               if (player instanceof LocalPlayer) {
                  LocalPlayer client = (LocalPlayer)player;
                  input = client.f_108618_;
               }

               if (KeyBindingToggleUtil.isFlying) {
                  Vec2 vec2f = input.m_108575_();
                  float f = player.m_6113_();
                  float h = f * vec2f.f_82470_;
                  float i = f * vec2f.f_82471_;
                  float j = Mth.m_14031_(player.m_146908_() * 0.017453292F);
                  float k = Mth.m_14089_(player.m_146908_() * 0.017453292F);
                  Vec2 vec2d = new Vec2(h * k - i * j, i * k + h * j);
                  double motionX = (double)(vec2d.f_82470_ * 5.0F);
                  double motionZ = (double)(vec2d.f_82471_ * 5.0F);
                  double motionY = input.f_108572_ ? 0.4D : (input.f_108573_ ? -0.4D : 0.0D);
                  player.m_20334_(motionX, motionY, motionZ);
               }
            }
         }
      }

   }

   public static void TickRegrowth(LivingEntity entity, ChestCavityInstance cc) {
      float growth = cc.getOrganScore(CCAAOrganScores.REGROWTH) - cc.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.REGROWTH);
      if (!(growth <= 0.0F) && entity.f_19797_ % CCAstroAdds.config.REGROWTH_COOLDOWN == 0) {
         AstralCavityUtil.growBackOrgans(entity, cc, growth);
      }

   }

   public static void TickTumorAutophagy(LivingEntity entity, ChestCavityInstance cc) {
      float autophagy = (float)Mth.m_14167_(cc.getOrganScore(CCAAOrganScores.TUMOR_AUTOPHAGY));
      if (!(autophagy <= 0.0F) && entity.f_19797_ % CCAstroAdds.config.AUTOPHAGY_COOLDOWN == 0) {
         AstralCavityUtil.eatOrgans(entity, cc, autophagy, true);
      }

   }

   public static void TickTumorHunt(LivingEntity entity, ChestCavityInstance cc) {
      float hunting = (float)Mth.m_14167_(cc.getOrganScore(CCAAOrganScores.TUMOR_HUNTING));
      if (!(hunting <= 0.0F) && entity.f_19797_ % CCAstroAdds.config.TUMOR_HUNTING_COOLDOWN == 0) {
         AstralCavityUtil.huntTumors(entity, cc, hunting);
      }

   }

   public static void TickSculkInfection(LivingEntity entity, ChestCavityInstance cc) {
      float sculk_infection = (float)Mth.m_14167_(cc.getOrganScore(CCAAOrganScores.SCULK_INFECTION));
      if (!(sculk_infection <= 0.0F) && entity.f_19797_ % CCAstroAdds.config.SCULK_INFECTION_COOLDOWN == 0) {
         AstralCavityUtil.infectOrgans(entity, cc, sculk_infection);
      }

   }

   public static void TickAutophagy(LivingEntity entity, ChestCavityInstance cc) {
      float autophagy = (float)Mth.m_14167_(cc.getOrganScore(CCAAOrganScores.AUTOPHAGY));
      if (!(autophagy <= 0.0F) && entity.f_19797_ % CCAstroAdds.config.AUTOPHAGY_COOLDOWN == 0) {
         AstralCavityUtil.eatOrgans(entity, cc, autophagy, false);
         AstralCavityUtil.drinkMilk(entity, cc);
      }

   }
}
