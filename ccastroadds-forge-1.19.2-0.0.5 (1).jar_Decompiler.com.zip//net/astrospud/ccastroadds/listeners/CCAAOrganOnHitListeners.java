package net.astrospud.ccastroadds.listeners;

import net.astrospud.ccastroadds.registration.CCAAOrganScores;
import net.astrospud.ccastroadds.registration.CCAAStatusEffects;
import net.astrospud.ccastroadds.specials.ClusterExplosion;
import net.astrospud.ccastroadds.specials.SafeExplosion;
import net.astrospud.ccastroadds.specials.ShriekerExplosion;
import net.minecraft.core.Position;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;

public class CCAAOrganOnHitListeners {
   public static void call(LivingEntity attacker, LivingEntity entity, ChestCavityInstance notused) {
      TickResonance(attacker, entity, notused);
      TickShrieking(attacker, entity, notused);
      TickClusterExplode(attacker, entity, notused);
   }

   public static void TickResonance(LivingEntity attacker, LivingEntity entity, ChestCavityInstance notused) {
      if (entity instanceof ChestCavityEntity) {
         ChestCavityInstance cc = ((ChestCavityEntity)entity).getChestCavityInstance();
         float resonance = cc.getOrganScore(CCAAOrganScores.RESONANCE) - cc.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.RESONANCE);
         float shrieking = cc.getOrganScore(CCAAOrganScores.SHRIEKING) - cc.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.SHRIEKING);
         resonance -= shrieking;
         if (!(resonance <= 0.0F) && !entity.m_21023_((MobEffect)CCAAStatusEffects.RESONANCE_COOLDOWN.get())) {
            entity.m_7292_(new MobEffectInstance((MobEffect)CCAAStatusEffects.RESONANCE_COOLDOWN.get(), (int)(75.0F / (resonance / 2.0F)), 0, false, false, true));
            Position entityPos = entity.m_20182_();
            double x = entityPos.m_7096_();
            double y = entityPos.m_7098_();
            double z = entityPos.m_7094_();
            float power = 5.0F;
            Level entityWorld = entity.m_9236_();
            SafeExplosion explosion = new SafeExplosion(entityWorld, entity, x, y, z, power);
            explosion.m_46061_();
            if (!entityWorld.f_46443_) {
               float rand = entityWorld.f_46441_.m_188501_() * 1.2F;
               entityWorld.m_5594_((Player)null, entity.m_20183_(), SoundEvents.f_144245_, SoundSource.BLOCKS, 7.0F, 0.5F + rand);
               entityWorld.m_5594_((Player)null, entity.m_20183_(), SoundEvents.f_144243_, SoundSource.BLOCKS, 7.0F, 0.5F + rand);
               entityWorld.m_5594_((Player)null, entity.m_20183_(), SoundEvents.f_144242_, SoundSource.BLOCKS, 2.0F, 2.5F + rand);
            }
         }
      }

   }

   public static void TickShrieking(LivingEntity attacker, LivingEntity entity, ChestCavityInstance notused) {
      if (entity instanceof ChestCavityEntity) {
         ChestCavityInstance cc = ((ChestCavityEntity)entity).getChestCavityInstance();
         float shrieking = cc.getOrganScore(CCAAOrganScores.SHRIEKING) - cc.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.SHRIEKING);
         if (!(shrieking <= 0.0F) && !entity.m_21023_((MobEffect)CCAAStatusEffects.SHRIEKING_COOLDOWN.get())) {
            entity.m_7292_(new MobEffectInstance((MobEffect)CCAAStatusEffects.SHRIEKING_COOLDOWN.get(), (int)(75.0F / (shrieking / 2.0F)), 0, false, false, true));
            Position entityPos = entity.m_20182_();
            double x = entityPos.m_7096_();
            double y = entityPos.m_7098_();
            double z = entityPos.m_7094_();
            float power = 5.0F;
            Level entityWorld = entity.m_9236_();
            ShriekerExplosion explosion = new ShriekerExplosion(entityWorld, entity, x, y, z, power);
            explosion.m_46061_();
            if (!entityWorld.f_46443_) {
               float rand = entityWorld.f_46441_.m_188501_() * 0.25F;
               entityWorld.m_5594_((Player)null, entity.m_20183_(), SoundEvents.f_215750_, SoundSource.BLOCKS, 2.0F, 0.8F + rand);
            }
         }
      }

   }

   public static void TickClusterExplode(LivingEntity attacker, LivingEntity entity, ChestCavityInstance notused) {
      if (entity instanceof ChestCavityEntity) {
         ChestCavityInstance cc = ((ChestCavityEntity)entity).getChestCavityInstance();
         float clusterBomb = cc.getOrganScore(CCAAOrganScores.CLUSTEREXPLODE) - cc.getChestCavityType().getDefaultOrganScore(CCAAOrganScores.CLUSTEREXPLODE);
         if (!(clusterBomb <= 0.0F)) {
            Position entityPos = entity.m_20182_();
            double x = entityPos.m_7096_();
            double y = entityPos.m_7098_();
            double z = entityPos.m_7094_();
            float power = 5.0F;
            Level entityWorld = entity.m_9236_();
            ClusterExplosion explosion = new ClusterExplosion(entityWorld, entity, x, y, z, power);
            explosion.m_46061_();
         }
      }

   }
}
