package net.astrospud.ccastroadds.registration;

import net.minecraft.resources.ResourceLocation;
import net.tigereye.chestcavity.registration.CCOrganScores;

public class CCAAOrganScores extends CCOrganScores {
   public static final ResourceLocation NEUTRAL_WATER_BUOYANT = new ResourceLocation("ccastroadds", "neutral_water_buoyant");
   public static final ResourceLocation PANIC = new ResourceLocation("ccastroadds", "panic");
   public static final ResourceLocation RESONANCE = new ResourceLocation("ccastroadds", "resonance");
   public static final ResourceLocation SHRIEKING = new ResourceLocation("ccastroadds", "shrieking");
   public static final ResourceLocation CLUSTEREXPLODE = new ResourceLocation("ccastroadds", "cluster_explode");
   public static final ResourceLocation FLIGHT = new ResourceLocation("ccastroadds", "flight");
   public static final ResourceLocation IRON_GUT = new ResourceLocation("ccastroadds", "iron_gut");
   public static final ResourceLocation EAT_THE_RICH = new ResourceLocation("ccastroadds", "eat_the_rich");
   public static final ResourceLocation REGROWTH = new ResourceLocation("ccastroadds", "regrowth");
   public static final ResourceLocation TUMOR_AUTOPHAGY = new ResourceLocation("ccastroadds", "tumor_autophagy");
   public static final ResourceLocation TUMOR_HUNTING = new ResourceLocation("ccastroadds", "tumor_hunting");
   public static final ResourceLocation SCULK_INFECTION = new ResourceLocation("ccastroadds", "sculk_infection");
   public static final ResourceLocation AUTOPHAGY = new ResourceLocation("ccastroadds", "autophagy");
}
