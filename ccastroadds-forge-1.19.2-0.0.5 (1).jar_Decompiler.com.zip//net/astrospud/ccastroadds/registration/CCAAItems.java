package net.astrospud.ccastroadds.registration;

import java.util.function.Supplier;
import net.astrospud.ccastroadds.CCAstroAdds;
import net.astrospud.ccastroadds.specials.DoniItem;
import net.astrospud.ccastroadds.specials.GlintItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class CCAAItems {
   public static final DeferredRegister<Item> ITEMS;
   public static final RegistryObject<Item> ABYSSAL_HEART;
   public static final RegistryObject<Item> ABYSSAL_LUNG;
   public static final RegistryObject<Item> ABYSSAL_MUSCLE;
   public static final RegistryObject<Item> ACTUATOR;
   public static final RegistryObject<Item> COPPER_WIRING;
   public static final RegistryObject<Item> COPPER_FRAME;
   public static final RegistryObject<Item> PHANTOM_PUMP;
   public static final RegistryObject<Item> FILTER_PUMP;
   public static final RegistryObject<Item> BLOOD_PUMP;
   public static final RegistryObject<Item> JUMP_SHAFT;
   public static final RegistryObject<Item> GOLDEN_WIRING;
   public static final RegistryObject<Item> CLOCKWORK_CORE;
   public static final RegistryObject<Item> GEM_HOLSTER;
   public static final RegistryObject<Item> ACID_MIXER;
   public static final RegistryObject<Item> ELECTROLYZER;
   public static final RegistryObject<Item> STEEL_ACTUATOR;
   public static final RegistryObject<Item> STEEL_CABLE;
   public static final RegistryObject<Item> STEEL_FRAME;
   public static final RegistryObject<Item> STEEL_DETOXIFIER;
   public static final RegistryObject<Item> STEEL_DISTRIBUTOR;
   public static final RegistryObject<Item> BOILER;
   public static final RegistryObject<Item> NUTRIENT_MIXER;
   public static final RegistryObject<Item> CRYSTAL_ROD;
   public static final RegistryObject<Item> CRYSTAL_CORE;
   public static final RegistryObject<Item> SHARDED_RIB;
   public static final RegistryObject<Item> CIRCUITRY;
   public static final RegistryObject<Item> SUPER_CAPACITOR;
   public static final RegistryObject<Item> REJUVENATED_RIB;
   public static final RegistryObject<Item> REJUVENATED_SPINE;
   public static final RegistryObject<Item> REANIMATED_HEART;
   public static final RegistryObject<Item> REANIMATED_KIDNEY;
   public static final RegistryObject<Item> CAPTURED_SOUL;
   public static final RegistryObject<Item> CREATIVE_SOUL;
   public static final RegistryObject<Item> IRON_LUNG;
   public static final RegistryObject<Item> HEART_OF_GOLD;
   public static final RegistryObject<Item> HASTY_MUSCLE;
   public static final RegistryObject<Item> SWIM_BLADDER;
   public static final RegistryObject<Item> RESONANT_CORE;
   public static final RegistryObject<Item> ADRENAL_CATALYST;
   public static final RegistryObject<Item> ADRENAL_SHRIEKER;
   public static final RegistryObject<Item> STEEL_STOMACH;
   public static final RegistryObject<Item> STEEL_RUMEN;
   public static final RegistryObject<Item> BENIGN_TUMOR;
   public static final RegistryObject<Item> AUTOPHAGY_TUMOR;
   public static final RegistryObject<Item> SCULK_TUMOR;
   public static final RegistryObject<Item> AUTOPHAGY_STOMACH;
   public static final RegistryObject<Item> EMPTY_CANISTER;
   public static final RegistryObject<Item> STEM_CELL_CANISTER;
   public static final RegistryObject<Item> NANOBOT_CANISTER;
   public static final RegistryObject<Item> SCULK_CANISTER;
   public static final RegistryObject<Item> CLUSTER_BOMB;
   public static final RegistryObject<Item> DRACONIS_FUNDAMENTUM;

   private static RegistryObject<Item> registerItem(String name, Supplier<Item> item) {
      return ITEMS.register(name, item);
   }

   public static void registerModItems() {
      CCAstroAdds.LOGGER.info("Registering Mod Items for ccastroadds");
   }

   static {
      ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "ccastroadds");
      ABYSSAL_HEART = registerItem("abyssal_heart", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      ABYSSAL_LUNG = registerItem("abyssal_lung", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      ABYSSAL_MUSCLE = registerItem("abyssal_muscle", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(16));
      });
      ACTUATOR = registerItem("actuator", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(16));
      });
      COPPER_WIRING = registerItem("copper_wiring", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      COPPER_FRAME = registerItem("copper_frame", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      PHANTOM_PUMP = registerItem("phantom_pump", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      FILTER_PUMP = registerItem("filter_pump", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      BLOOD_PUMP = registerItem("blood_pump", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      JUMP_SHAFT = registerItem("jump_shaft", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(16));
      });
      GOLDEN_WIRING = registerItem("golden_wiring", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      CLOCKWORK_CORE = registerItem("clockwork_core", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      GEM_HOLSTER = registerItem("gem_holster", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      ACID_MIXER = registerItem("acid_mixer", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      ELECTROLYZER = registerItem("electrolyzer", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      STEEL_ACTUATOR = registerItem("steel_actuator", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(16));
      });
      STEEL_CABLE = registerItem("steel_cable", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      STEEL_FRAME = registerItem("steel_frame", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      STEEL_DETOXIFIER = registerItem("steel_detoxifier", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      STEEL_DISTRIBUTOR = registerItem("steel_distributor", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      BOILER = registerItem("boiler", () -> {
         return new Item((new Properties()).m_41487_(1));
      });
      NUTRIENT_MIXER = registerItem("nutrient_mixer", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      CRYSTAL_ROD = registerItem("crystal_rod", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(16));
      });
      CRYSTAL_CORE = registerItem("crystal_core", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      SHARDED_RIB = registerItem("sharded_rib", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      CIRCUITRY = registerItem("circuitry", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      SUPER_CAPACITOR = registerItem("super_capacitor", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      REJUVENATED_RIB = registerItem("rejuvenated_rib", () -> {
         return new GlintItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(4));
      });
      REJUVENATED_SPINE = registerItem("rejuvenated_spine", () -> {
         return new GlintItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      REANIMATED_HEART = registerItem("reanimated_heart", () -> {
         return new GlintItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      REANIMATED_KIDNEY = registerItem("reanimated_kidney", () -> {
         return new GlintItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      CAPTURED_SOUL = registerItem("captured_soul", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      CREATIVE_SOUL = registerItem("creative_soul", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      IRON_LUNG = registerItem("iron_lung", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      HEART_OF_GOLD = registerItem("heart_of_gold", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      HASTY_MUSCLE = registerItem("hasty_muscle", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(16));
      });
      SWIM_BLADDER = registerItem("swim_bladder", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      RESONANT_CORE = registerItem("resonant_core", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      ADRENAL_CATALYST = registerItem("adrenal_catalyst", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      ADRENAL_SHRIEKER = registerItem("adrenal_shrieker", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      STEEL_STOMACH = registerItem("steel_stomach", () -> {
         return new DoniItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      STEEL_RUMEN = registerItem("steel_rumen", () -> {
         return new DoniItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      BENIGN_TUMOR = registerItem("benign_tumor", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      AUTOPHAGY_TUMOR = registerItem("autophagy_tumor", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      SCULK_TUMOR = registerItem("sculk_tumor", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      AUTOPHAGY_STOMACH = registerItem("autophagy_stomach", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      EMPTY_CANISTER = registerItem("empty_canister", () -> {
         return new Item((new Properties()).m_41491_(CreativeModeTab.f_40759_).m_41487_(16));
      });
      STEM_CELL_CANISTER = registerItem("stem_cell_canister", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      NANOBOT_CANISTER = registerItem("nanobot_canister", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      SCULK_CANISTER = registerItem("sculk_canister", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      CLUSTER_BOMB = registerItem("cluster_bomb", () -> {
         return new Item((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
      DRACONIS_FUNDAMENTUM = registerItem("draconis_fundamentum", () -> {
         return new GlintItem((new Properties()).m_41491_(CCAstroAdds.ORGAN_ITEM_GROUP).m_41487_(1));
      });
   }
}
