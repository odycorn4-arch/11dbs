package net.astrospud.ccastroadds.registration;

import net.astrospud.ccastroadds.specials.ChestOpenerDispenserBehavior;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.DispenserBlock;
import net.tigereye.chestcavity.registration.CCItems;

public class CCAADispenserBehaviors {
   public static void register() {
      DispenserBlock.m_52672_(((Item)CCItems.CHEST_OPENER.get()).m_5456_(), new ChestOpenerDispenserBehavior());
   }
}
