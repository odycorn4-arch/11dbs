package net.astrospud.ccastroadds.registration;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.tigereye.chestcavity.mob_effect.CCStatusEffect;

public class CCAAStatusEffects {
   public static final DeferredRegister<MobEffect> MOB_EFFECTS;
   public static final RegistryObject<MobEffect> RESONANCE_COOLDOWN;
   public static final RegistryObject<MobEffect> SHRIEKING_COOLDOWN;
   public static final RegistryObject<MobEffect> PANIC;

   static {
      MOB_EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, "ccastroadds");
      RESONANCE_COOLDOWN = MOB_EFFECTS.register("resonance_cooldown", () -> {
         return new CCStatusEffect(MobEffectCategory.NEUTRAL, 0);
      });
      SHRIEKING_COOLDOWN = MOB_EFFECTS.register("shrieking_cooldown", () -> {
         return new CCStatusEffect(MobEffectCategory.NEUTRAL, 0);
      });
      PANIC = MOB_EFFECTS.register("panic", () -> {
         return (new CCStatusEffect(MobEffectCategory.BENEFICIAL, 15883877)).m_19472_(Attributes.f_22279_, "b8f27012-8795-4ac8-95ef-1a88bd132494", 0.600000009D, Operation.MULTIPLY_TOTAL);
      });
   }
}
